﻿Detalhamos a proposta do jogo, presente no GDD, explicando melhor os comandos do personagem,
a IA dos inimigos e a estrutura básica da tela do site.
Começamos a modificar a tela inicial no HTML/CSS para se adequar a nossa proposta.

Próximos passos:
* Sistema de vidas
* Sistema de fases
* Formulário de término do jogo
* Diferentes inimigos
* Variação de dificuldade

